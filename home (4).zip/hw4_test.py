"""
Cynthia Hong
CSE 163 AF
This file is for putting my test of HW4.
The program is the implement specialized data types
with Python classes for tf-idf information retrieval.
"""
from cse163_utils import assert_equals

from document import Document
from search_engine import SearchEngine


# Define your test functions here!
def test_document():
    """
    Tests the test_document.
    """
    docu_1 = Document('/home/home/files/file_1.txt')
    docu_2 = Document('/home/home/files/file_2.txt')
    docu_3 = Document('/home/home/files/file_3.txt')
    assert_equals(1/3, docu_1.term_frequency('I'))
    assert_equals(1/3, docu_2.term_frequency('love'))
    assert_equals(0, docu_3.term_frequency('pupies'))
    assert_equals(['i', 'love', 'corgis'], docu_1.get_words())
    assert_equals(['i', 'love', 'puppies'], docu_2.get_words())
    assert_equals('/home/home/files/file_3.txt', docu_3.get_path())


def test_search():
    """
    Tests the test_search.
    """
    test = SearchEngine('/home/home/files/')
    assert_equals(0, test._calculate_idf('love'))
    assert_equals(['/home/home/files/file_1.txt'],
                  test.search('corgis'))
    assert_equals(['/home/home/files/file_1.txt',
                   '/home/home/files/file_2.txt',
                   '/home/home/files/file_3.txt'], test.search('love'))


def main():
    # Call your test functions here!
    test_document()
    test_search()


if __name__ == '__main__':
    main()
