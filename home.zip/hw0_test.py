"""
Cynthia Hong
CSE 163 AF
This program makes tests for HW0
"""
# import the contextof hw0
import hw0

# import a function from cse163_utils
from cse163_utils import assert_equals


def test_total():
    """
    tests the function of total from hw0
    """
    # The regular case
    assert_equals(15, hw0.total(5))
    # Seems likely we could mess up 0 or 1
    assert_equals(1, hw0.total(1))
    assert_equals(0, hw0.total(0))
    assert_equals(None, hw0.total(-3))


def test_funky_sum():
    """
    tests the function of funky_sum from hw0
    """
    # Two calls shown in the specification
    assert_equals(2.0, hw0.funky_sum(1, 3, 0.5))
    assert_equals(1, hw0.funky_sum(1, 3, 0))
    # Two calls I make up
    assert_equals(10, hw0.funky_sum(1, 10, 100))
    assert_equals(2, hw0.funky_sum(2, 3, -0.111))


def test_swip_swap():
    """
    tests the function of swip_swap from hw0
    """
    # Two calls shown in the specification
    assert_equals('offbar', hw0.swip_swap('foobar', 'f', 'o'))
    assert_equals('foocar', hw0.swip_swap('foobar', 'b', 'c'))
    # Two calls I make up
    assert_equals('kaolo', hw0.swip_swap('koala', 'a', 'o'))
    assert_equals('cynthai', hw0.swip_swap('cynthia', 'i', 'a'))


def main():
    test_total()
    test_funky_sum()
    test_swip_swap()


if __name__ == '__main__':
    main()
