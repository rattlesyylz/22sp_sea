# Education Data Analysis

## 1. Do you think the bar chart for `bar_chart_high_school` is an effective data visualization?
No, because the percertage for 'A', 'F', and 'M' are all above 80 and are nearly the same.
For example, the percentage of 'A' and 'F' are really close to each other, which is difficult to
find which is higher. The graph without the detailed number of y-axis let us be hard to read the
specific percentage of each bar. Thus, I think this graph could not help us make obvious conclusion
and show some relation, which could not further solve social problems, and that's why I think the bar 
chart for `bar_chart_high_school` is not an effective data visualization.


## 2. How and why did you choose the `plot for plot_hispanic_min_degree`?
I choose the line chart of the graph to plot `plot for plot_hispanic_min_degree`.
The reason is that since we want to find the changing trend the percentage of Hispanic people
with degrees between 1990–2010, line chart chould help us easily show out the changeing trend
with respect to the time pass of the year.


## 3. Describe a possible bias present in this dataset and why it might have occurred.
There are some blank data, which I think might produce some bias for our data analyzation.
The reason is that some individuals might refuse to show their educational degree, and the blank
data might also produce by the loss of the information. Also, we could not find out if people
report the wrong information for some personal reason, for they were careless, or they believed
their degree was lower than they expected. Therefore, the accuracy of the dataset might produce bias.


## 4. Describe an application, analysis, or decision motivated by this dataset with the intended goal of improving educational equity but that ultimately exacerbates social injustice.
Government’s intend to improve educational equality might invest education funds for the people with high school’s Min degree, since from the graph of plot_hispanic_min_degree.png,
there is a the huge difference between the percentage of high school and bachelor's Min degree. However, if we consider specific circumstances, such as people need to end their studies
earlier to work, government’s fund might be unnecessary and increase social gap. 

Moreover, when government wants to improve educational equality for helping to increase number of people in a specific group, they might receive a false result when they utilize the
decision tree to predict. If result suggests government to invest a false group, which means this group actually has higher percentage or number Min Degree than other groups, government’s
funding may invest in the wrong group and eventually exacerbate social injustice.
