# Food Desert Analysis

## What is one way that government officials could use `plot_food_access_by_county` or `plot_low_access_tracts` to shape public policy on how to improve food access?
From the graph of plot_low_access_tracts, to improve food access, I think government officials could provide some subsidies for food access in low food access, blue areas.
For example, to reduce high-speed fares on vehicles that transport things to these places.
Or to produce the social welfare in such area, such as handing out more food to these places.


## What is a limitation or concern with using the plots in this way?
From the graph of plot_low_access_tracts, although the blue area tells us
the low food access area, these areas are so large that we cannot compare which area of food
is more low access. As a result, we can't find the small range of areas with the
lowest access, and it is difficult for us to find which areas the government need to help first.
Therefore, the limitation is that we cannot identify the specific areas of low
food access that need the most help by goverment.
