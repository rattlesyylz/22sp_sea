"""
Cynthia Hong
CSE 163 AF
This program makes tests for HW2 with both manual and pandas.
"""

import pandas as pd

from cse163_utils import assert_equals, parse

import hw2_manual
import hw2_pandas

# If you want to include more global constants,
# please check the code quality guide!
SPEC_TEST_FILE = "/home/pokemon_test.csv"
MY_SPEC_TEST_FILE = "/home/my_own_data.csv"


def test_species_count(data1, data2, data3, data4):
    """
    Tests the species_count method with both manual and pandas.
    data1 and data3 are dataset of pokemon, and data2 and data4 are
    DataFrama.
    """
    assert_equals(3, hw2_manual.species_count(data1))
    assert_equals(3, hw2_pandas.species_count(data2))
    assert_equals(5, hw2_manual.species_count(data3))
    assert_equals(5, hw2_pandas.species_count(data4))


def test_max_level(data1, data2, data3, data4):
    """
    Tests the max_level method with both manual and pandas.
    data1 and data3 are dataset of pokemon, and data2 and data4 are
    DataFrama.
    """
    assert_equals(('Lapras', 72), hw2_manual.max_level(data1))
    assert_equals(('Lapras', 72), hw2_pandas.max_level(data2))
    assert_equals(('Magmar', 44), hw2_manual.max_level(data3))
    assert_equals(('Magmar', 44), hw2_pandas.max_level(data4))


def test_filter_range(data1, data2, data3, data4):
    """
    Tests the filter_range method with both manual and pandas.
    data1 and data3 are dataset of pokemon, and data2 and data4 are
    DataFrama.
    """
    assert_equals(['Arcanine', 'Arcanine', 'Starmie'],
                  hw2_manual.filter_range(data1, 35, 72))
    assert_equals(['Arcanine', 'Arcanine', 'Starmie'],
                  hw2_pandas.filter_range(data2, 35, 72))
    assert_equals(['Persian', 'Magmar', 'Kingler', 'Venusaur'],
                  hw2_manual.filter_range(data3, 30, 80))
    assert_equals(['Persian', 'Magmar', 'Kingler', 'Venusaur'],
                  hw2_pandas.filter_range(data4, 30, 80))


def test_mean_attack_for_type(data1, data2, data3, data4):
    """
    Tests the mean_attack_for_type method with both manual and pandas.
    data1 and data3 are dataset of pokemon, and data2 and data4 are
    DataFrama.
    """
    assert_equals(47.5, hw2_manual.mean_attack_for_type(data1, 'fire'))
    assert_equals(47.5, hw2_pandas.mean_attack_for_type(data2, 'fire'))
    assert_equals(110.0, hw2_manual.mean_attack_for_type(data3, 'water'))
    assert_equals(110.0, hw2_pandas.mean_attack_for_type(data4, 'water'))


def test_count_types(data1, data2, data3, data4):
    """
    Tests the count_types method with both manual and pandas.
    data1 and data3 are dataset of pokemon, and data2 and data4 are
    DataFrama.
    """
    assert_equals({'fire': 2, 'water': 2}, hw2_manual.count_types(data1))
    assert_equals({'fire': 2, 'water': 2}, hw2_pandas.count_types(data2))
    assert_equals({'normal': 1, 'fire': 1, 'water': 1, 'fighting': 1,
                  'grass': 1}, hw2_manual.count_types(data3))
    assert_equals({'normal': 1, 'fire': 1, 'water': 1, 'fighting': 1,
                  'grass': 1}, hw2_pandas.count_types(data4))


def test_mean_attack_per_type(data1, data2, data3, data4):
    """
    Tests the mean_attack_per_typel method with both manual and pandas.
    data1 and data3 are dataset of pokemon, and data2 and data4 are
    DataFrama.
    """
    assert_equals({'fire': 47.5, 'water': 140.5},
                  hw2_manual.mean_attack_per_type(data1))
    assert_equals({'fire': 47.5, 'water': 140.5},
                  hw2_pandas.mean_attack_per_type(data2))
    assert_equals({'normal': 104.0, 'fire': 96.0, 'water': 110.0, 'fighting':
                  20.0, 'grass': 136.0}, hw2_manual.mean_attack_per_type(data3)
                  )
    assert_equals({'normal': 104.0, 'fire': 96.0, 'water': 110.0, 'fighting':
                  20.0, 'grass': 136.0}, hw2_pandas.mean_attack_per_type(data4)
                  )


def main():
    spec_test_data = parse(SPEC_TEST_FILE)      # a list of dictionaries
    spec_test_df = pd.read_csv(SPEC_TEST_FILE)  # a DataFrame
    my_spec_test_data = parse(MY_SPEC_TEST_FILE)
    my_spec_test_df = pd.read_csv(MY_SPEC_TEST_FILE)
    # Feel free to use these datasets in your tests!
    test_species_count(spec_test_data, spec_test_df,
                       my_spec_test_data, my_spec_test_df)
    test_max_level(spec_test_data, spec_test_df,
                   my_spec_test_data, my_spec_test_df)
    test_filter_range(spec_test_data, spec_test_df,
                      my_spec_test_data, my_spec_test_df)
    test_mean_attack_for_type(spec_test_data, spec_test_df,
                              my_spec_test_data, my_spec_test_df)
    test_count_types(spec_test_data, spec_test_df,
                     my_spec_test_data, my_spec_test_df)
    test_mean_attack_per_type(spec_test_data, spec_test_df,
                              my_spec_test_data, my_spec_test_df)


if __name__ == '__main__':
    main()
